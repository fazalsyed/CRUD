//
//  EmployeDataVC.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 12/07/23.
//

import UIKit

class EmployeDataVC: UIViewController {
    
    @IBOutlet var searchBar: UISearchBar!
    var data = [Employe]()
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        data = DatabaseHelper.shareInstance.fetchdata()
        tableView.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
}
extension EmployeDataVC : UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lblempname.text = "Employee Name: " +  (data[indexPath.row].empname ?? "")
        cell.lbldesignation.text = "Employee Designation: " +  (data[indexPath.row].empdesgnation ?? "")
        cell.lbladdress.text = "Employee Address: " +  (data[indexPath.row].empaddress ?? "")
        cell.lblsalary.text = "Employee Salary: " + (data[indexPath.row].empsalary ?? "")
        let selectedView = UIView()
        selectedView.backgroundColor = UIColor.clear
        cell.selectedBackgroundView = selectedView
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            data = DatabaseHelper.shareInstance.deletedata(index: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EmpShowDataVC") as? EmpShowDataVC
        vc?.empData = data[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        var dh = DatabaseHelper()
        if searchText != ""
        {
            data = dh.searchdata(empname: searchText)
            tableView.reloadData()
        }
        else{
            data = dh.fetchdata()
            tableView.reloadData()
        }
    }
}


