//
//  DatabaseHelper.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 12/07/23.
//

import Foundation
import UIKit
import CoreData


class DatabaseHelper{
    
    static let shareInstance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    //Marks : Function is used to Save Data.
    func savedata(empdict : [String : String]){
        let data = NSEntityDescription.insertNewObject(forEntityName: "Employe", into: context!) as? Employe
        data?.empname = empdict["empname"]
        data?.empdesgnation = empdict["empdesgnation"]
        data?.empaddress = empdict["empaddress"]
        data?.empsalary = empdict["empsalary"]
        do{
            try context?.save()
        }
        catch{
            print("data Not saved")
        }
    }
    //Marks : Function is used to Fetch Data.
    func fetchdata() -> [Employe]{
        var data = [Employe]()
        let fetch = NSFetchRequest<NSManagedObject>(entityName: "Employe")
        do{
            data = try (context?.fetch(fetch) as? [Employe])!
        }
        catch{
            print("Data not fetched")
        }
        return data
    }
    //Marks : Function is used to Delete Data.
    func deletedata(index : Int) -> [Employe]{
        var data = fetchdata()
        context?.delete(data[index])
        data.remove(at: index)
        do{
            try context?.save()
        }
        catch{
            print("Data not deeleted")
        }
        return data
    }
    //Marks : Function is used to Edit Data.
    func editdata(empdict : [String : String],index : Int){
        var data = fetchdata()
        data[index].empname = empdict["empname"]
        data[index].empdesgnation = empdict["empdesgnation"]
        data[index].empaddress = empdict["empaddress"]
        data[index].empsalary = empdict["empsalary"]
        do{
            try context?.save()
        }
        catch{
            print("data Not saved")
        }
    }
    //Marks : Function is used to Search Data.
    func searchdata(empname : String) -> [Employe]{
        var data = [Employe]()
        let predicate = NSPredicate(format: "empname contains %@", empname)
        let request : NSFetchRequest = Employe.fetchRequest()
        request.predicate = predicate
        do{
            data = try ((context?.fetch(request) as? [Employe])!)
        }
        catch{
            print("data not fetched")
        }
        return data
    }
}
