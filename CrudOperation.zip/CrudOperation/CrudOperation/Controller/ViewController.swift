//
//  ViewController.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 12/07/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var txtEmployeName: UITextField!
    @IBOutlet var txtEmployeDesignation: UITextField!
    @IBOutlet var txtEmployeSalary: UITextField!
    @IBOutlet var txtEmployeAddress: UITextField!
    @IBOutlet var btnSave: UIButton!
    var editEmp : Employe?
    var isUpdate = false
    var indexRow = Int()
    var isSaving = false
    override func viewDidLoad() {
        super.viewDidLoad()
        UiUpdate()
    }
    
    //Marks : UIUpdate Function
    func UiUpdate(){
        txtEmployeName.text = editEmp?.empname
        txtEmployeDesignation.text = editEmp?.empdesgnation
        txtEmployeSalary.text = editEmp?.empsalary
        txtEmployeAddress.text = editEmp?.empaddress
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if isUpdate{
            btnSave.setTitle("Update", for: .normal)
        }
        else{
            btnSave.setTitle("Save", for: .normal)
        }
    }
    @IBAction func btnTappedSave(_ sender: UIButton) {
        if isSaving {
            return
        }
        isSaving = true
        if validateFields() {
            savadata()
        } else {
            isSaving = false
        }
    }
    
    @IBAction func btnTappedShow(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EmployeDataVC") as! EmployeDataVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func savadata(){
        guard let empname = txtEmployeName.text else{return}
        guard let empdesgnation = txtEmployeDesignation.text else{return}
        guard let empsalary = txtEmployeSalary.text else{return}
        guard let empaddress  = txtEmployeAddress.text else {return}
        
        let empdict = ["empname" : empname,
                       "empdesgnation" : empdesgnation,
                       "empsalary" : empsalary,
                       "empaddress" : empaddress]
        if isUpdate{
            DatabaseHelper.shareInstance.editdata(empdict: empdict, index: indexRow)
        }
        else{
            DatabaseHelper.shareInstance.savedata(empdict: empdict)
        }
        
    }
    //Marks : Validation fucntion for textField.
    func validateFields() -> Bool {
        // Check the employee name
        guard let name = txtEmployeName.text, !name.isEmpty, !containsNumbers(name) else {
            showAlert(message: "Please enter a valid name.")
            return false
        }
        
        // Check the employee designation
        guard let designation = txtEmployeDesignation.text, !designation.isEmpty, !containsNumbers(designation) else {
            showAlert(message: "Please enter a valid designation.")
            return false
        }
        
        // Check the employee salary
        guard let salaryText = txtEmployeSalary.text, !salaryText.isEmpty, let salary = Double(salaryText), salary >= 0 else {
            showAlert(message: "Please enter a valid, non-negative employee salary.")
            return false
        }
        
        // Check the employee address (optional)
        if let address = txtEmployeAddress.text, address.isEmpty || address.count > 25 {
            showAlert(message: "Please enter a valid address (1-25 characters).")
            return false
        }
        return true
    }
    
    func containsNumbers(_ string: String) -> Bool {
        let range = string.rangeOfCharacter(from: .decimalDigits)
        return range != nil
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}

