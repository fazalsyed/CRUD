//
//  EmpShowDataVC.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 12/07/23.
//

import UIKit

class EmpShowDataVC: UIViewController {
    
    var empData : Employe?
    var indexRow = Int()
    @IBOutlet var lblempname: UILabel!
    @IBOutlet var lblempdesignation: UILabel!
    @IBOutlet var lbladdress: UILabel!
    @IBOutlet var lblsalary: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblempname.text = "Employee Name: " + (empData?.empname ?? "")
        lblempdesignation.text = "Employee Desgnation: " + (empData?.empdesgnation ?? "")
        lblsalary.text = "Employee Salary: " + (empData?.empsalary ?? "")
        lbladdress.text = "Employee Address: " + (empData?.empaddress ?? "")
    }
    @IBAction func btnTappedEdit(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        vc?.editEmp = empData
        vc?.indexRow = indexRow
        vc?.isUpdate = true
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
