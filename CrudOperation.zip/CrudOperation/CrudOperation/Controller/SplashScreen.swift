//
//  SplashScreen.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 13/10/23.
//

import UIKit


@available(iOS 13.0, *)
class SplashScreen: UIViewController {

    @IBOutlet weak var splashImageView: UIImageView!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Delay for a few seconds (adjust as needed)
        let delayInSeconds = 3.0
        
        DispatchQueue.main.asyncAfter(deadline: .now() + delayInSeconds) {
            UIView.animate(withDuration: 0.5, animations: {
                // Fade out the splash screen
                self.splashImageView.alpha = 0.0
            }) { (_) in
                // Transition to your main view controller
                self.transitionToMainViewController()
            }
        }
    }
    
    @available(iOS 13.0, *)
    func transitionToMainViewController() {
        let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as? ViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    @available(iOS 13.0, *)
    @IBAction func btnTappedNextView(_ sender: UIButton) {
        transitionToMainViewController()
    }
}
