//
//  Employe+CoreDataClass.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 12/07/23.
//
//

import Foundation
import CoreData

@objc(Employe)
public class Employe: NSManagedObject {

}
