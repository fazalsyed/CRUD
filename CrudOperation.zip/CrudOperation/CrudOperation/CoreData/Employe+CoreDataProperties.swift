//
//  Employe+CoreDataProperties.swift
//  CrudOperation
//
//  Created by syed fazal abbas on 12/07/23.
//
//

import Foundation
import CoreData


extension Employe {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Employe> {
        return NSFetchRequest<Employe>(entityName: "Employe")
    }

    @NSManaged public var empname: String?
    @NSManaged public var empdesgnation: String?
    @NSManaged public var empsalary: String?
    @NSManaged public var empaddress: String?

}

extension Employe : Identifiable {

}
